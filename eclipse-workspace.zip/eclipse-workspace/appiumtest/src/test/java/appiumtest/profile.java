package appiumtest;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
public class profile {
	static AppiumDriver<MobileElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities  cap = new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME,"ANDROID");
		cap.setCapability(MobileCapabilityType.PLATFORM_VERSION	,"14");
		cap.setCapability(MobileCapabilityType.DEVICE_NAME,"jn8ppzjzwsvcwkpr");
		cap.setCapability(MobileCapabilityType.AUTOMATION_NAME,"UIAutomator2");
		cap.setCapability("appPackage", "com.bluboy.android.test");
		cap.setCapability("appActivity", "com.bluboy.android.ui.splash.SplashActivity");
		cap.setCapability("autoGrantPermissions", true);
		URL url=new URL("http://127.0.0.1:4723");
		driver = new AppiumDriver<>(url,cap);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		MobileElement MobileNumber=driver.findElementById("com.bluboy.android.test:id/editTextMobile");
		MobileNumber.sendKeys("9949721349");
		MobileElement CheckBox=driver.findElementById("com.bluboy.android.test:id/checkBoxLogin");
		CheckBox.click();
		MobileElement Signup=driver.findElementByXPath("//*[@text='SIGNUP / LOGIN']");
		Signup.click();
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		MobileElement otp=driver.findElementById("com.bluboy.android.test:id/pinView");
		otp.sendKeys("1111");
		MobileElement verify=driver.findElementByXPath("//*[@text='VERIFY']");
		verify.click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		MobileElement profile=driver.findElementById("com.bluboy.android.test:id/ivPlayerProfile");
		profile.click();
		MobileElement profile_edit=driver.findElementById("com.bluboy.android.test:id/imgEdit");
		profile_edit.click();
		MobileElement profile_pic_edit=driver.findElementById("com.bluboy.android.test:id/imageViewEditProfile");
		profile_pic_edit.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		MobileElement pic=driver.findElementById("com.google.android.providers.media.module:id/icon_thumbnail");
		pic.click();
		MobileElement crop=driver.findElementById("com.bluboy.android.test:id/settings");
		crop.click();
		MobileElement update=driver.findElementById("com.bluboy.android.test:id/button_text");
		update.click();
		
		MobileElement updated_picture=driver.findElementById("com.bluboy.android.test:id/imgProfile");
		
		}}
