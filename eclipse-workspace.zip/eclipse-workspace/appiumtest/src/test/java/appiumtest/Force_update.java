package appiumtest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;
public class Force_update {

	static AppiumDriver<MobileElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities  cap = new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME,"ANDROID");
		cap.setCapability(MobileCapabilityType.PLATFORM_VERSION	,"14");
		cap.setCapability(MobileCapabilityType.DEVICE_NAME,"jn8ppzjzwsvcwkpr");
		cap.setCapability(MobileCapabilityType.AUTOMATION_NAME,"UIAutomator2");
		cap.setCapability("appPackage", "com.bluboy.android.test");
		cap.setCapability("appActivity", "com.bluboy.android.ui.splash.SplashActivity");
		cap.setCapability("autoGrantPermissions", true);
		URL url=new URL("http://127.0.0.1:4723");
		driver = new AppiumDriver<>(url,cap);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		try {
	
			MobileElement update_now=driver.findElementById("com.bluboy.android.test:id/btnYes");
			update_now.click();
			MobileElement download_now=driver.findElementById("com.bluboy.android.test:id/btnDownload");
			download_now.click();
			try {
				MobileElement Manage_all_files=driver.findElementByXPath("//*[@text='Allow access to manage all files']");
				Manage_all_files.click();
				driver.executeScript("mobile: pressKey", Map.ofEntries(Map.entry("keycode", 4)));
			}
			catch(Exception e) {
				System.out.println("Manage all Files Alredy Enabled");}
			finally {
				try {
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					MobileElement Allow_from_Source=driver.findElementByXPath("//*[@text='Allow from this source']");			
					Allow_from_Source.click();
					
					MobileElement Caution_check=driver.findElementById("com.miui.securitycenter:id/check_box");
					Caution_check.click();
					
					Thread.sleep(15000);
					
					MobileElement Caution_ok=driver.findElementByXPath("//*[@text='OK']");
					Caution_ok.click();
					driver.executeScript("mobile: pressKey", Map.ofEntries(Map.entry("keycode", 4)));
					
					MobileElement Download_Apk=driver.findElementById("com.bluboy.android.test:id/btnDownload");
					Download_Apk.click();
					}
					catch(NoSuchElementException x)
					{
						System.out.println("ALLOW FROM SOURCE ALREDY GRANTED");
						driver.executeScript("mobile: pressKey", Map.ofEntries(Map.entry("keycode", 4)));
					}
					finally {
					MobileElement update_popup=driver.findElementById("com.android.packageinstaller:id/button1");
					update_popup.click();
					}
			}
			
			
			
		}
		catch(NoSuchElementException e) {
			
			System.out.println("force_update not found");
	
		}
}
	}
